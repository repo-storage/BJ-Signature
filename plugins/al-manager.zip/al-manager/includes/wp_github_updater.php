<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of wp_github_updater
 *
 * @author studio
 */

include_once WP_PLUGIN_DIR.'/al-manager/includes/updater.php';

class wp_github_updater {

    public function __construct() {

    }

}

?>
