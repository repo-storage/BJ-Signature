<?php


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * EXT_WPNavs - Qucikly add wordpress custom menus to your themes
 * <code>
 * <?php
 * //add a primary nav menu
 * EXT_WPNavs::add_menu()->set_menu_class('nav')->set_depth(0)->set_theme_location('primary')->menu();
 * //adds a custom item to the primary menu  - runs after/on init.
 * EXT_WPNavs::add_menu()->set_theme_location('primary')->add_loginout();
 *
 * ?>
 * http://codex.wordpress.org/Function_Reference/wp_nav_menu
 * http://www.wpbeginner.com/wp-themes/how-to-add-custom-items-to-specific-wordpress-menus/
 * </code>
 * @author studio
 */
class Ext_WPNavs {

     private $menu,
            $theme_location = 'primary',
            $fallback_cb = array('EXT_WPNavs','default_menu'),
            $depth = 0,
            $link_before = '',
            $link_after = '',
            $before = '',
            $after = '',
            $echo = true,
            $container = false,
            $container_class = '',
            $menu_class = '',
            $walker,
            $items = "",
            $menu_name = "",
            $items_wrap = '<ul id=\"%1$s\" class=\"%2$s\">%3$s</ul>',
            $menu_array = array();

    public function set_items_wrap($items_wrap) {
        $this->items_wrap = $items_wrap;
        return $this;
    }

    public function set_container_class($container_class) {
        $this->container_class = $container_class;
        return $this;
    }

    public function set_walker($walker) {
        $this->walker = $walker;
        return $this;
    }

    public function set_items($items) {
        $this->items = $items;
        return $this;
    }

    public function set_menu_name($menu_name) {
        $this->menu_name = $menu_name;
        return $this;
    }

    public function set_menu($menu) {
        $this->menu = $menu;
        return $this;
    }

    public function set_theme_location($theme_location) {
        $this->theme_location = $theme_location;
        return $this;
    }

    public function set_fallback_cb($fallback_cb) {
        $this->fallback_cb = array($this, 'default_menu');
        return $this;
    }

    public function set_depth($depth) {
        $this->depth = $depth;
        return $this;
    }

    public function set_link_before($link_before) {
        $this->link_before = $link_before;
        return $this;
    }

    public function set_link_after($link_after) {
        $this->link_after = $link_after;
        return $this;
    }

    public function set_before($before) {
        $this->before = $before;
        return $this;
    }

    public function set_after($after) {
        $this->after = $after;
        return $this;
    }

    public function set_echo($echo) {
        $this->echo = $echo;
        return $this;
    }

    public function set_container($container) {
        $this->container = $container;
        return $this;
    }

    public function set_menu_class($menu_class) {
        $this->menu_class = $menu_class;
        return $this;
    }

    public function set_menu_array($menu_array) {
        $this->menu_array = $menu_array;
        return $this;
    }


    public function __construct() {

    }

    /**
     * Factory pattern
     * @return \EXT_WPNavs
     */
    public function add(){
        return new EXT_WPNavs();
    }

    /**
     * <code>
     * cwp_navs::factory()->set_depth(0)->tbs_menu('primary');
     * </code>
     * @param type $theme_location
     * @return \cwp_navs
     */
    public function build_menu() {
        //$this->theme_location = $theme_location;

        wp_nav_menu(array(
            'theme_location' => $this->theme_location,
            'fallback_cb' => $this->fallback_cb,
            'container' => $this->container,
            'container_class' => $this->container_class,
            'menu_class' => $this->menu_class,
            'echo' => $this->echo,
            'before' => $this->before,
            'after' => $this->after,
            'link_before' => $this->link_before,
            'link_after' => $this->link_after,
            'depth' => $this->depth,
            'walker' => $this->walker
        ));
        return $this;
    }


    public function add_loginout(){
        add_filter('wp_nav_menu_items', array($this,'loginout'),10, 2 );
    }

    /**
     * @param type $items
     * @param type $args
     * @param type $location
     * @return string
     */
    public function loginout($items, $args) {
        if (is_user_logged_in() && $args->theme_location == $this->theme_location) {
            $items .= '<li><a href="' . wp_logout_url() . '">' . __('Log Out', 'corewp') . '</a></li>';
        } elseif (!is_user_logged_in() && $args->theme_location == $this->theme_location) {
            $items .= '<li><a href="' . site_url('wp-login.php') . '">' . __('Log In', 'corewp') . '</a></li>';
        }
        return $items;
    }

    /**
     */
    public function add_search(){
        add_filter('wp_nav_menu_items', array($this,'add_search_box'));
    }


    /**
     *
     * @param type $items
     * @param type $args
     * @param type $location
     * @return type
     */
    public function add_search_box($items, $args) {
        if ($args->theme_location == $location)
            return $items . "<li class='menu-header-search'><form action='http://example.com/' id='searchform' method='get'><input type='text' name='s' id='s' placeholder='" . __('Search', 'corewp') . "></form></li>";
        return $items;
    }

}



class nav_walker extends Walker_Nav_Menu {
    // http://wordpress.stackexchange.com/questions/14037/menu-items-description/14039#14039

    /**
     * Start the element output.
     *
     * @param  string $output Passed by reference. Used to append additional content.
     * @param  object $item   Menu item data object.
     * @param  int $depth     Depth of menu item. May be used for padding.
     * @param  array $args    Additional strings.
     * @return void
     */
    function start_el(&$output, $item, $depth, $args) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;

        $class_names = join(
                ' '
                , apply_filters(
                        'nav_menu_css_class'
                        , array_filter($classes), $item
                )
        );

        !empty($class_names)
                and $class_names = ' class="' . esc_attr($class_names) . '"';

        $output .= "<li id='menu-item-$item->ID' $class_names>";

        $attributes = '';

        !empty($item->attr_title)
                and $attributes .= ' title="' . esc_attr($item->attr_title) . '"';
        !empty($item->target)
                and $attributes .= ' target="' . esc_attr($item->target) . '"';
        !empty($item->xfn)
                and $attributes .= ' rel="' . esc_attr($item->xfn) . '"';
        !empty($item->url)
                and $attributes .= ' href="' . esc_attr($item->url) . '"';

        // insert description for top level elements only
        // you may change this
        $description = (!empty($item->description) and 0 == $depth ) ? '<small class="nav_desc">' . esc_attr($item->description) . '</small>' : '';

        $title = apply_filters('the_title', $item->title, $item->ID);

        $item_output = $args->before
                . "<a $attributes>"
                . $args->link_before
                . $title
                . '</a> '
                . $args->link_after
                . $description
                . $args->after;

        // Since $output is called by reference we don't need to return anything.
        $output .= apply_filters(
                'walker_nav_menu_start_el'
                , $item_output
                , $item
                , $depth
                , $args
        );
    }

}

