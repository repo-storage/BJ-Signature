<footer id="footer">
    <address id="about" class="vcard body">
        <span class="primary">
            <strong><a href="#" class="fn url">Smashing Magazine</a></strong>

            <span class="role">Amazing Magazine</span>
        </span><!-- /.primary -->

        <img src="images/avatar.gif" alt="Smashing Magazine Logo" class="photo" />
        <span class="bio">Smashing Magazine is a website and blog that offers resources and advice to web developers and web designers. It was founded by Sven Lennartz and Vitaly Friedman.</span>
    </address><!-- /#about -->
    <p>2005-2009 <a href="http://smashingmagazine.com">Smashing Magazine</a>.</p>
</footer><!-- /#contentinfo -->