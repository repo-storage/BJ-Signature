<header>
    <hgroup>
        <h1>Grouped Heading 1</h1>
        <h2>Grouped Heading 2</h2>
    </hgroup>
    <nav>
        <ul>
            <li><a href="#">navigation item #1</a></li>
            <li><a href="#">navigation item #2</a></li>
            <li><a href="#">navigation item #3</a></li>
        </ul>
    </nav>
</header>
