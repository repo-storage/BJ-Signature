<?php
/**
 * @package WordPress
 * @subpackage Core.WP
 */
?>
<div>
    <strong>1</strong> There are tons of options you can use to control how and when
    your slide transitions occur.  Test them out and see what
    ones you like.  Check out the many examples on this website
    and see which ones catch your eye.
    <ul>
        <li>col -1</li>
        <li>col -2</li>
    </ul>

</div>