<div>
    <span class="slider-img">
        <?php the_post_thumbnail('slidershow-image'); ?>
    </span>
    <span class="content">
        <h3><?php the_title(); ?></h3>
        <p><?php the_excerpt(); ?></p>
    </span>
</div>