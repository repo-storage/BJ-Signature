<div id="cycle">
    <div>
        <strong>1</strong> There are tons of options you can use to control how and when
        your slide transitions occur.  Test them out and see what
        ones you like.  Check out the many examples on this website
        and see which ones catch your eye.
        <ul>
            <li>col -1</li>
            <li>col -2</li>
        </ul>

    </div>
    <div>
        <strong>2</strong> There are tons of options you can use to control how and when
        your slide transitions occur.  Test them out and see what
        ones you like.  Check out the many examples on this website
        and see which ones catch your eye.
        <ul>
            <li>col -1</li>
            <li>col -2</li>
        </ul>

    </div>
    <div>
        <strong>3</strong> There are tons of options you can use to control how and when
        your slide transitions occur.  Test them out and see what
        ones you like.  Check out the many examples on this website
        and see which ones catch your eye.
        <ul>
            <li>col -1</li>
            <li>col -2</li>
        </ul>
    </div>
</div>


