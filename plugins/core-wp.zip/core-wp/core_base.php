<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of core_base
 *
 * @author Studio365
 */


abstract class module_base {

    abstract public function load() ;


    abstract public function config() ;


    abstract public function tpl() ;

}

?>
