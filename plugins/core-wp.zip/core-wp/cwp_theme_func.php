<?php

/**
 * @package WordPress
 * @subpackage core.wp
 */

define('CWP_PATH', dirname(__FILE__) . '/core-wp');
define('CWP_URL', get_stylesheet_directory_uri() . '/core-wp' );

require_once CWP_PATH .'/cwp.php';

?>
