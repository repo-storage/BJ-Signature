<?php

/**
 * @package WordPress
 * @subpackage basejump
 * @author shawnsandy
 */

cwp_layout::use_tpl('home-page');
