<?php

/**
 * @package WordPress
 * @subpackage Core-WP
 * @author shawnsandy
 */

cwp_layout::use_tpl('full-page');


?>
