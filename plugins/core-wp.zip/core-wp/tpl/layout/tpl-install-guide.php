<?php

/**
 * @package WordPress
 * @subpackage Core-WP
 * @author shawnsandy
 */
cwp_layout::main_tpl();
?>

