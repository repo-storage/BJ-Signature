<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<strong style="color: #999999">
    This is a sample tpl-widget you can find this file in the themes tpl/widgets folder. Use it to quickly include custom code into your themes.
</strong>

<p style="margin-top: 20px">
    <em>Example function : bloginfo('description);</em><br />
    <?php bloginfo('description'); ?>
</p>